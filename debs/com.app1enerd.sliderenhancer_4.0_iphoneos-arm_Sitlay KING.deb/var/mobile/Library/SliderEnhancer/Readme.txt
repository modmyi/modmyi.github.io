slider.png = Slider image for 3GS etc.
slider@2x.png = Slider image for iPhone 4, 4S
slider-72.png = Slider for iPad.

Please keep on the original size of the image, so will be less problems please!